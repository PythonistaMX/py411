var nombre = prompt("Por favor escriba su nombre");
var mensaje = document.getElementById("mensaje");
alert("Hola " + nombre + ". ¿Desea reservar?");